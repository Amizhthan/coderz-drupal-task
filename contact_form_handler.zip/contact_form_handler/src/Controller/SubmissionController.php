<?php
namespace Drupal\contact_form_handler\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;

class SubmissionController extends ControllerBase {
  public function viewSubmissions() {
    // Connect to the database.
    $connection = Database::getConnection();
    // Query the custom table.
    $query = $connection->select('custom_contact_submissions', 'c')
      ->fields('c', ['id', 'full_name', 'phone_number', 'email', 'address', 'time', 'date']);
    $results = $query->execute()->fetchAll();

    // Build table rows from the query results.
    $rows = [];
    foreach ($results as $row) {
      $rows[] = [
        'data' => [
          $row->id,
          $row->full_name,
          $row->phone_number,
          $row->email,
          $row->address,
          $row->time,
          $row->date,
        ],
      ];
    }

    // Build render array for the table.
    $header = [
      'ID', 'Full Name', 'Phone Number', 'Email', 'Address', 'Time', 'Date',
    ];
    $build['submissions_table'] = [
      '#type' => 'table',
      '#header' => $header,
      '#rows' => $rows,
      '#empty' => $this->t('No submissions found.'),
    ];

    return $build;
  }
}
